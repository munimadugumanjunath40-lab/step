Week 1 Java Assignment — 5 Problems

Files:
1. SeatDuplicationChecker.java
2. TypingAccuracyChecker.java
3. TrafficSignalAnalyzer.java
4. InventoryBalancer.java
5. WordLengthProfiler.java

How to compile and run:
1. Install a Java JDK.
2. Open Command Prompt in this folder.
3. Compile a program, for example:
   javac SeatDuplicationChecker.java
4. Run it:
   java SeatDuplicationChecker

Repeat the compile/run commands with the other file names.

Each Java file is a separate program and has its own main method.
