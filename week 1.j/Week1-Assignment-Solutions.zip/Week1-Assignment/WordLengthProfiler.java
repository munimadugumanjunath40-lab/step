import java.util.Scanner;

public class WordLengthProfiler {
    static void classifyWordLengths(String review) {
        int shortWords = 0;
        int mediumWords = 0;
        int longWords = 0;

        String trimmedReview = review.trim();
        if (!trimmedReview.isEmpty()) {
            String[] words = trimmedReview.split("\\s+");

            for (String word : words) {
                String lettersOnly = word.replaceAll("[^A-Za-z]", "");
                int length = lettersOnly.length();

                if (length >= 1 && length <= 4) {
                    shortWords++;
                } else if (length >= 5 && length <= 8) {
                    mediumWords++;
                } else if (length >= 9) {
                    longWords++;
                }
            }
        }

        System.out.println("Short: " + shortWords
                + " | Medium: " + mediumWords
                + " | Long: " + longWords);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter movie review:");
        String review = sc.nextLine();

        classifyWordLengths(review);
        sc.close();
    }
}
